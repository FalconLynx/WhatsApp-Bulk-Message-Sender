import pyautogui
import time

print("--- Fast WhatsApp Auto Messenger (No Tab Reload) ---")

# ১. প্রয়োজনীয় ইনপুটগুলো
phone_number = input("নম্বর দিন (যেমন 017XXXXXXXX): ").strip()
message = input("কী মেসেজ পাঠাতে চান?: ")
total_count = int(input("মোট কয়টি মেসেজ পাঠাবেন?: "))
delay = float(input("প্রতি মেসেজের মাঝে কত সেকেন্ড বিরতি চান? (যেমন: 0.2 বা 0.5): "))

print("\n!!! সতর্কতা: ৫ সেকেন্ডের মধ্যে ব্রাউজারে হোয়াটসঅ্যাপ ওপেন করে নির্দিষ্ট আইডিটির চ্যাট-বক্সে মাউস ক্লিক করে রাখো !!!")

for i in range(5, 0, -1):
    print(f"{i} সেকেন্ড বাকি...")
    time.sleep(1)

print("\nমেসেজ পাঠানো শুরু হচ্ছে...")

# ২. সরাসরি এক চ্যাটে দ্রুত মেসেজ পাঠানো
for i in range(1, total_count + 1):
    full_message = f"{message} ({i})"
    pyautogui.typewrite(full_message)
    pyautogui.press('enter')
    
    print(f"[{i}/{total_count}] সেন্ড হয়েছে: {full_message}")
    
    if i < total_count:
        time.sleep(delay)

print("\nসব মেসেজ সফলভাবে পাঠানো শেষ!")